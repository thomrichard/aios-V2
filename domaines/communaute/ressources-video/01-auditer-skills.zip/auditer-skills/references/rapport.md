# Modèle de rapport

## En-tête

- Date de l'audit, périmètre (emplacements et nombre de skills), skills exclues et pourquoi (plugin, éditeur tiers, copie synchronisée).
- En une phrase : l'état général.

## Une section par skill

### `<nom-de-la-skill>` — `<chemin>`

| # | Règle | Statut | Preuve (fichier:ligne) | Correction proposée |
|---|---|---|---|---|
| 4 | Lue en entier : sommaire en tête des longs fichiers | OK / à corriger / non applicable | `references/x.md` : 180 lignes, pas de sommaire | Ajouter en tête : « ## Sommaire » + liste des titres |

- Une ligne par règle principale (1 à 7). Les compléments (8 à 14) et le contrôle « une seule copie » n'apparaissent que s'ils sont à corriger.
- La correction est écrite telle qu'elle sera appliquée : texte exact à ajouter, à remplacer ou à déplacer.
- Si une règle relève du jugement, dire en une phrase sur quoi il repose.

## Priorités

Liste numérotée de toutes les corrections, toutes skills confondues :

1. **Risque** : étape risquée trop libre (règle 2), dépendance manquante qui casse la skill ailleurs (règle 7).
2. **Fiabilité** : description qui empêche le déclenchement (règle 1), annexes hors d'atteinte ou longs fichiers sans sommaire (règle 4), vérification absente (règles 5 et 6), copies différentes d'une même skill.
3. **Confort** : insistance héritée d'anciens modèles et mention des modèles testés (règle 3), concision (règle 8), vocabulaire (règle 10).

Chaque ligne : skill, règle, correction en une phrase, effort estimé (petit, moyen).

## Fin

Terminer par la question : « Quelles corrections veux-tu appliquer ? (numéros, « toutes », ou « aucune ») ».
