# Règles d'audit

Origine indiquée pour chaque règle :
- **Guide Anthropic** : [Skill authoring best practices](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices), relu le 5 octobre 2026.
- **Recommandation Club SMART** : pratique ajoutée, non exigée par le guide.

Statuts possibles : **OK**, **à corriger**, **non applicable**.

Les sept règles suivent la vie d'une skill : qu'elle soit trouvée (1), ce qu'on lui dit (2, 3), qu'elle soit lue en entier (4), qu'elle vérifie son travail (5, 6), qu'elle voyage (7). C'est l'ordre de la vidéo et de la page thomrichard.com/audit-skills.

## Sommaire

- Les 7 règles principales
  1. Une description qui permet de trouver la skill
  2. Degrés de liberté adaptés au risque
  3. L'objectif, pas le mode d'emploi, pour les modèles visés
  4. Lue en entier : un seul niveau, fiche courte, sommaire
  5. Boucle de vérification
  6. Liste à cocher quand l'ordre compte
  7. Dépendances déclarées
- Compléments du guide
  8. Concision
  9. Pas d'information datée
  10. Vocabulaire constant
  11. Plan validé avant une action risquée
  12. Scripts clairs et robustes
  13. Outils MCP et chemins
  14. Évaluations
- Contrôle en plus : une seule copie

## Les 7 règles principales

### 1. Une description qui permet de trouver la skill · *Guide Anthropic*
**On vérifie :** au démarrage, Claude ne lit que le nom et la description de chaque skill pour choisir laquelle ouvrir. `name` : 64 caractères au plus, minuscules, chiffres et tirets, sans « anthropic » ni « claude ». `description` : non vide, 1 024 caractères au plus, dit **ce que fait** la skill puis **quand** l'utiliser, avec les mots que l'utilisateur emploierait.
**À corriger :** description à la première ou à la deuxième personne (« Je peux… », « Tu peux m'utiliser… ») ; description qui ne dit pas quand l'utiliser.
**Preuve :** l'en-tête de `SKILL.md`, relevé par le script.

### 2. Degrés de liberté adaptés au risque · *Guide Anthropic*
**On vérifie :** pour chaque étape, ce qui se passe si Claude la fait autrement.
**OK :** consigne libre quand plusieurs approches conviennent ; modèle à suivre avec quelques réglages quand une forme est préférée ; commande exacte ou script, sans variation, quand l'étape est fragile ou irréversible (argent, envoi, suppression, publication). Une même skill peut mélanger les niveaux.
**À corriger :** une étape risquée décrite en texte libre, ou une étape créative enfermée dans une procédure rigide.
**Preuve :** l'étape, son fichier et sa ligne.

### 3. L'objectif, pas le mode d'emploi, pour les modèles visés · *Guide Anthropic* (mention du modèle : *Recommandation Club SMART*)
**On vérifie :** la skill donne l'objectif, ce qui compte et les points où il ne faut pas se tromper, plutôt qu'un mode d'emploi geste par geste. Elle est écrite pour les modèles qui l'exécuteront, et essayée avec chacun. Questions du guide : avec Haiku, est-elle assez guidée ? Avec Sonnet, est-elle claire et efficace ? Avec Opus, évite-t-elle d'en dire trop ?
**À corriger :** insistance héritée d'anciens modèles (majuscules, « IMPORTANT », « TOUJOURS », « MUST » répétés, listes de cas à n'en plus finir) hors des étapes où une erreur coûte cher ; branches « si tel modèle, fais ceci » (une seule version, testée sur chaque modèle visé).
**Recommandation :** une ligne « Testée avec : … » dans le corps de `SKILL.md`. Cette ligne documente le test ; elle ne change pas le modèle utilisé. Son absence seule donne « à corriger », en priorité confort.
**À savoir :** le guide n'exige que `name` et `description`. Claude Code reconnaît en plus un champ `model` (et `context: fork` pour faire exécuter la skill par un agent séparé) ; ces champs sont ignorés dans claude.ai et par l'API, où le modèle de la conversation exécute la skill. Ne signaler un champ `model` que s'il vise un modèle absent ou si la skill est destinée à claude.ai ou à l'API.
**Preuve :** les passages concernés (fichier:ligne) ; présence ou absence de la mention « Testée avec ». L'audit ne peut pas prouver un test qui n'est pas documenté.

### 4. Lue en entier : un seul niveau, fiche courte, sommaire · *Guide Anthropic*
**On vérifie :**
- le corps de `SKILL.md` fait moins de 500 lignes ;
- chaque fichier annexe est lié directement depuis `SKILL.md`, aucun n'est atteignable seulement via un autre fichier ;
- tout fichier de plus de 100 lignes commence par un sommaire qui reprend ses titres ;
- les annexes sont découpées par domaine, avec des noms qui disent leur contenu.
**Pourquoi :** quand une annexe renvoie vers une autre, Claude peut n'en lire que le début ; le sommaire lui montre tout ce que le fichier contient.
**Preuve :** longueurs, sommaires, liens et fichiers orphelins, donnés par le script.

### 5. Boucle de vérification · *Guide Anthropic*
**On vérifie :** quand la qualité compte, la skill contrôle son résultat contre quelque chose de concret (script, guide de style, document de voix, liste de critères), corrige, puis contrôle à nouveau avant de livrer.
**À corriger :** une relecture vague (« vérifie que c'est bien ») sans référence ni consigne de reprise.

### 6. Liste à cocher quand l'ordre compte · *Guide Anthropic*
**On vérifie :** une tâche en plusieurs étapes dont l'ordre importe donne une liste à recopier et cocher, avec une consigne de retour (« si … échoue, revenir à l'étape X »).
**Non applicable :** quand l'ordre des étapes est indifférent ; une liste n'y apporte rien.

### 7. Dépendances déclarées · *Guide Anthropic*
**On vérifie :** chaque script ou bibliothèque a sa ligne d'installation et son import à côté (ex. `pip install pypdf`, puis `from pypdf import PdfReader`).
**À savoir :** dans claude.ai, une skill peut installer des paquets ; par l'API Claude, elle n'a ni réseau ni installation. Une skill prévue pour l'API ne doit dépendre que de ce qui est déjà disponible.
**Preuve :** imports hors bibliothèque standard sans ligne d'installation, relevés par le script.

## Compléments du guide

### 8. Concision · *Guide Anthropic*
N'écrire que ce que Claude ne sait pas déjà. À signaler : explications générales, plusieurs options sans choix par défaut.

### 9. Pas d'information datée · *Guide Anthropic*
Pas de « avant telle date, faire ceci ». La méthode actuelle d'abord ; l'ancienne, si utile, dans une section « anciennes façons de faire ».

### 10. Vocabulaire constant · *Guide Anthropic*
Un seul mot par notion dans toute la skill.

### 11. Plan validé avant une action risquée · *Guide Anthropic*
Pour les traitements en lot ou destructifs : produire un plan dans un fichier, le valider (script ou contrôle), puis exécuter et vérifier.

### 12. Scripts clairs et robustes · *Guide Anthropic*
La skill dit si un script est à **exécuter** ou à **lire**. Les erreurs sont gérées dans le script plutôt que laissées à Claude. Les valeurs fixes sont justifiées par un commentaire.

### 13. Outils MCP et chemins · *Guide Anthropic*
Outils MCP désignés par leur nom complet, avec le serveur (`Serveur:outil`). Chemins écrits avec `/`.

### 14. Évaluations · *Guide Anthropic*
Au moins trois scénarios de test, avec le comportement attendu, et un essai en usage réel. Idéalement écrits avant la skill, à partir des erreurs que Claude fait sans elle, puis relancés à chaque modification ou changement de modèle. L'audit signale leur absence ; il ne les invente pas sans demande.

## Contrôle en plus : une seule copie · *Recommandation Club SMART*
Une skill présente à plusieurs endroits avec des contenus différents est à corriger : on ne sait pas laquelle Claude utilise. Garder une seule source, et des liens vers elle si besoin.
