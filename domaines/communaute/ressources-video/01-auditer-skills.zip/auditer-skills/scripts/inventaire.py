#!/usr/bin/env python3
"""Inventaire mesuré des skills Claude, pour la skill auditer-skills.

Mesure, sans rien modifier : emplacement, en-tête, longueurs, sommaires,
liens depuis SKILL.md, fichiers hors d'atteinte directe, imports de scripts.
Bibliothèque standard uniquement (Python 3.10+).

Usage :
    python3 inventaire.py              # emplacements par défaut
    python3 inventaire.py DOSSIER...   # dossiers de skills ou skill seule
    python3 inventaire.py --json
"""
import ast
import json
import re
import sys
from pathlib import Path

# Seuils du guide Anthropic (Skill authoring best practices).
SEUIL_SOMMAIRE = 100     # lignes au-delà desquelles un sommaire est attendu
SEUIL_SKILL_MD = 500     # lignes maximum conseillées pour le corps de SKILL.md
NOM_MAX, DESCRIPTION_MAX = 64, 1024
# Un sommaire est cherché dans les 30 premières lignes : au-delà, il ne remplit plus son rôle.
ZONE_SOMMAIRE = 30
# Affichage texte : au-delà, renvoyer au détail JSON pour rester lisible.
MAX_ALERTES = 8

EMPLACEMENTS_PAR_DEFAUT = [
    Path(".claude/skills"), Path(".agents/skills"), Path(".ai/skills"),
    Path.home() / ".claude/skills", Path.home() / ".agents/skills",
]
TEXTE = {".md", ".txt"}
SCRIPTS = {".py", ".js", ".mjs", ".ts", ".sh"}
STDLIB = set(getattr(sys, "stdlib_module_names", ()))
LIEN = re.compile(r"\]\(<?([^)>#\s]+)>?(?:#[^)]*)?\)|`([\w./-]+\.(?:md|py|js|mjs|ts|sh|txt|json|yaml|html))`")
TITRE_SOMMAIRE = re.compile(r"^#+\s*(sommaire|contents|table des mati[eè]res|table of contents)\b", re.I)
INSTALL = re.compile(r"\b(pip3? install|uv (?:pip|add)|npm (?:i|install)|pnpm add|yarn add|brew install)\b")


def lignes(p):
    try:
        return p.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []


def entete(txt):
    """Lit les champs simples de l'en-tête YAML (clé: valeur sur une ligne)."""
    if not txt or txt[0].strip() != "---":
        return {}, 0
    champs, fin = {}, 0
    for i, l in enumerate(txt[1:], 1):
        if l.strip() == "---":
            fin = i
            break
        m = re.match(r"^([A-Za-z_-]+):\s*(.*)$", l)
        if m:
            champs[m.group(1)] = m.group(2).strip().strip("\"'")
    return champs, fin


def categorie(chemin):
    s = str(chemin)
    if "/plugins/" in s or "/synced/" in s:
        return "plugin-ou-synchronisee"
    if s.startswith(str(Path.home() / ".agents")) or s.startswith(str(Path.home() / ".claude")):
        return "globale"
    return "projet"


def liens(txt, dossier, racine):
    trouves = set()
    for l in txt:
        for m in LIEN.finditer(l):
            cible = m.group(1) or m.group(2)
            if "://" in cible:
                continue
            p = (dossier / cible).resolve()
            if p.is_file() and racine in p.parents:
                trouves.add(p)
    return trouves


def imports(p, txt):
    mods = set()
    if p.suffix == ".py":
        try:
            arbre = ast.parse("\n".join(txt))
        except SyntaxError:
            return []
        for n in ast.walk(arbre):
            if isinstance(n, ast.Import):
                mods |= {a.name.split(".")[0] for a in n.names}
            elif isinstance(n, ast.ImportFrom) and n.module and not n.level:
                mods.add(n.module.split(".")[0])
        locaux = {f.stem for f in p.parent.glob("*.py")}
        return sorted(m for m in mods if m not in STDLIB and m not in locaux and m != "__future__")
    if p.suffix in {".js", ".mjs", ".ts"}:
        for l in txt:
            s = l.strip()
            if s.startswith(("//", "*", "/*")):
                continue
            if s.startswith(("import ", "export ")) or "require(" in s:
                for m in re.finditer(r"(?:from\s+|import\s+|require\()\s*['\"]([^'\"./][^'\"]*)['\"]", s):
                    mods.add(m.group(1).split("/")[0] if not m.group(1).startswith("@") else "/".join(m.group(1).split("/")[:2]))
        return sorted(m for m in mods if not m.startswith(("node:", "bun:")))
    return []


def analyser(skill):
    racine = skill.resolve()
    smd = racine / "SKILL.md"
    txt = lignes(smd)
    champs, fin = entete(txt)
    nom, desc = champs.get("name", ""), champs.get("description", "")
    alertes = []
    if not nom:
        alertes.append("en-tête : name absent")
    elif len(nom) > NOM_MAX or not re.fullmatch(r"[a-z0-9-]+", nom) or re.search(r"anthropic|claude", nom):
        alertes.append(f"en-tête : name non conforme ({nom})")
    if not desc:
        alertes.append("en-tête : description absente ou sur plusieurs lignes (à vérifier à la main)")
    elif len(desc) > DESCRIPTION_MAX:
        alertes.append(f"en-tête : description de {len(desc)} caractères (> {DESCRIPTION_MAX})")
    elif re.match(r"^(je |j'|tu |vous |i |you )", desc, re.I):
        alertes.append("en-tête : description à la première ou deuxième personne")
    corps = len(txt) - (fin + 1 if fin else 0)
    if corps > SEUIL_SKILL_MD:
        alertes.append(f"SKILL.md : corps de {corps} lignes (> {SEUIL_SKILL_MD})")

    directs = liens(txt, racine, racine)
    fichiers, tout_texte = [], "\n".join(txt)
    for p in sorted(racine.rglob("*")):
        if not p.is_file() or p == smd or any(x.startswith(".") for x in p.relative_to(racine).parts):
            continue
        rel = str(p.relative_to(racine))
        t = lignes(p) if p.suffix in TEXTE | SCRIPTS else []
        if p.suffix in TEXTE | SCRIPTS:
            tout_texte += "\n" + "\n".join(t)
        info = {"fichier": rel, "lignes": len(t), "lie_depuis_skill_md": p.resolve() in directs}
        if p.suffix in TEXTE and len(t) > SEUIL_SOMMAIRE:
            info["sommaire"] = any(TITRE_SOMMAIRE.match(l) for l in t[:ZONE_SOMMAIRE])
            if not info["sommaire"]:
                alertes.append(f"{rel} : {len(t)} lignes sans sommaire en tête")
        if p.suffix in SCRIPTS:
            info["imports_externes"] = imports(p, t)
        fichiers.append(info)

    # Références : fichiers texte non liés directement depuis SKILL.md.
    for f in fichiers:
        if Path(f["fichier"]).suffix in TEXTE and not f["lie_depuis_skill_md"]:
            alertes.append(f"{f['fichier']} : non lié directement depuis SKILL.md")
    a_installer = sorted({m for f in fichiers for m in f.get("imports_externes", [])})
    if a_installer and not INSTALL.search(tout_texte):
        alertes.append("scripts : imports externes sans ligne d'installation (" + ", ".join(a_installer) + ")")

    return {
        "skill": nom or racine.name, "chemin": str(skill), "categorie": categorie(skill),
        "skill_md_lignes": len(txt), "corps_lignes": corps,
        "mention_testee_avec": bool(re.search(r"test[ée]e? avec|tested with", tout_texte, re.I)),
        "liste_a_cocher": "- [ ]" in tout_texte,
        "fichiers": fichiers, "alertes": alertes,
    }


def trouver(cibles):
    vus, skills = set(), []
    for c in cibles:
        c = c.expanduser()
        if not c.is_dir():
            continue
        candidats = [c] if (c / "SKILL.md").is_file() else [d for d in sorted(c.iterdir()) if (d / "SKILL.md").is_file()]
        # Un niveau de plus pour les dossiers qui regroupent des skills (ex. synced/<compte>/<skill>).
        for d in sorted(c.iterdir()) if not (c / "SKILL.md").is_file() else []:
            if d.is_dir() and not (d / "SKILL.md").is_file():
                candidats += [e for e in sorted(d.iterdir()) if e.is_dir() and (e / "SKILL.md").is_file()]
        for d in candidats:
            r = d.resolve()
            if r not in vus:
                vus.add(r)
                skills.append(d)
    return skills


def main():
    if sys.version_info < (3, 10):
        sys.exit("Python 3.10 ou plus récent requis (liste des modules standard). Essayer : python3.11 inventaire.py")
    args = [a for a in sys.argv[1:] if a != "--json"]
    cibles = [Path(a) for a in args] or EMPLACEMENTS_PAR_DEFAUT
    res = [analyser(s) for s in trouver(cibles)]
    if "--json" in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return
    print(f"{len(res)} skill(s) trouvée(s)\n")
    for r in res:
        etat = "RAS" if not r["alertes"] else f"{len(r['alertes'])} point(s)"
        print(f"## {r['skill']} [{r['categorie']}] — {r['chemin']}")
        print(f"   SKILL.md {r['skill_md_lignes']} lignes · {len(r['fichiers'])} autre(s) fichier(s) · "
              f"« testée avec » : {'oui' if r['mention_testee_avec'] else 'non'} · liste à cocher : "
              f"{'oui' if r['liste_a_cocher'] else 'non'} · {etat}")
        for a in r["alertes"][:MAX_ALERTES]:
            print(f"   - {a}")
        if len(r["alertes"]) > MAX_ALERTES:
            print(f"   - … et {len(r['alertes']) - MAX_ALERTES} autre(s) (détail avec --json)")
        print()
    noms = {}
    for r in res:
        noms.setdefault(r["skill"], []).append(r["chemin"])
    doublons = {n: c for n, c in noms.items() if len(c) > 1}
    if doublons:
        print(f"Skills présentes en plusieurs copies distinctes ({len(doublons)}) :")
        for n, c in sorted(doublons.items()):
            print(f"   - {n} : " + " · ".join(c))


if __name__ == "__main__":
    main()
