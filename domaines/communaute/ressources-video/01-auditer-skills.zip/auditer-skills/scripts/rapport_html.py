#!/usr/bin/env python3
"""Rapport HTML de l'audit des skills, pour la skill auditer-skills.

Lance l'inventaire (inventaire.py, même dossier), ajoute les dépendances de
chaque skill, puis remplit le modèle assets/rapport-audit.html. Lecture seule
sur les skills. Bibliothèque standard uniquement (Python 3.10+).

Usage :
    python3 rapport_html.py                          # emplacements par défaut
    python3 rapport_html.py DOSSIER...               # dossiers de skills ou skill seule
    python3 rapport_html.py --sortie rapport.html    # sinon : rapport-audit-skills.html
    python3 rapport_html.py --jugements jugements.json
    python3 rapport_html.py --sortie -               # HTML sur la sortie standard

Fichier de jugements (facultatif), produit par l'audit pour les règles qui
demandent une lecture (2, 3, 5, 6) :
    {"nom-de-skill": {"2": {"statut": "ok" | "a_corriger" | "na",
                            "preuve": "fichier:ligne …", "correction": "…"}}}
"""
import datetime
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODELE = ICI.parent / "assets" / "rapport-audit.html"
VERROU = Path.home() / ".agents" / ".skill-lock.json"  # sources des skills installées par `npx skills`
BALISE = re.compile(r'(<script id="audit-data" type="application/json">)(.*?)(</script>)', re.S)
MCP = re.compile(r"mcp__([A-Za-z0-9-]+?)__")
COMMANDE = re.compile(r"\b(?:npx\s+(?:-y\s+)?|uvx\s+|brew install\s+|pip3? install\s+|npm (?:i|install) (?:-g\s+)?)(@?[a-z0-9][\w./@-]*)")
# Mots captés par erreur après « npx », « pip install »… dans de la prose.
# Une famille = skills d'un même éditeur ou d'un même préfixe (gws-…), à partir de ce nombre.
FAMILLE_MIN = 3
# Contenu de SKILL.md repris dans la page, borné pour garder un fichier léger.
CONTENU_MAX = 40_000
MOTS_VIDES = {"skills", "through", "in", "beside", "commands", "the", "a", "to", "it", "and", "or", "your"}


def charger_inventaire():
    sys.dont_write_bytecode = True  # pas de __pycache__ dans le dossier de la skill
    spec = importlib.util.spec_from_file_location("inventaire", ICI / "inventaire.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def textes(dossier, inv):
    """Contenu de SKILL.md et des fichiers texte ou scripts de la skill."""
    racine = Path(dossier).resolve()
    morceaux = []
    for p in sorted(racine.rglob("*")):
        if p.is_file() and p.suffix in inv.TEXTE | inv.SCRIPTS and not any(
                x.startswith(".") for x in p.relative_to(racine).parts):
            morceaux.append(p.read_text(encoding="utf-8", errors="replace"))
    return "\n".join(morceaux)


def empreinte(dossier):
    h = hashlib.sha1()
    racine = Path(dossier).resolve()
    for p in sorted(racine.rglob("*")):
        if p.is_file() and not any(x.startswith(".") for x in p.relative_to(racine).parts):
            h.update(str(p.relative_to(racine)).encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def sources():
    try:
        d = json.loads(VERROU.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {k: {"source": v.get("source"), "mis_a_jour": (v.get("updatedAt") or "")[:10]}
            for k, v in (d.get("skills") or d).items() if isinstance(v, dict)}


def statut_regles(r, doublon):
    al = r["alertes"]
    def a(motif):
        return [x for x in al if motif in x]
    longs = [f for f in r["fichiers"] if "sommaire" in f]
    som = a("sans sommaire")
    struct = a("non lié directement") + a("corps de")
    deps = a("sans ligne d'installation")
    entete = a("en-tête")
    a_scripts = any(f.get("imports_externes") for f in r["fichiers"])
    # Numéros des règles de references/regles.md ; la règle 4 est mesurée en deux parties.
    return {
        "1": {"statut": "a_corriger" if entete else "ok", "preuves": entete},
        "4": {"statut": "a_corriger" if struct else "ok", "preuves": struct},
        "4-sommaire": {"statut": "a_corriger" if som else ("ok" if longs else "na"), "preuves": som},
        "7": {"statut": "a_corriger" if deps else ("ok" if a_scripts else "na"), "preuves": deps},
        "copies": {"statut": "a_corriger" if doublon == "differentes" else ("info" if doublon else "ok")},
    }


def familles(skills):
    """Range chaque skill dans une famille : éditeur connu, sinon préfixe partagé, sinon renvoi unique."""
    prefixe = lambda n: n.split("-")[0]
    compte = {}
    for s in skills:
        compte[prefixe(s["nom"])] = compte.get(prefixe(s["nom"]), 0) + 1
    for s in skills:
        if s["source"]:
            s["famille"] = s["source"].split("/")[-1].removesuffix(".git")
            if s["famille"] in ("cli", "skills"):
                s["famille"] = s["source"].split("/")[0]
        elif compte[prefixe(s["nom"])] >= FAMILLE_MIN:
            s["famille"] = prefixe(s["nom"])
        else:
            s["famille"] = None
    connues = {s["famille"] for s in skills if s["famille"]}
    for s in skills:
        if not s["famille"]:
            vues = {f for f in connues
                    for x in s["dependances"]["skills"] + s["dependances"]["commandes"] if x == f or x.startswith(f + "-")}
            if len(vues) == 1:
                s["famille"] = vues.pop()


def construire(cibles, jugements):
    inv = charger_inventaire()
    trouvees = inv.trouver(cibles)
    res = [(d, inv.analyser(d)) for d in trouvees]
    src = sources()

    par_nom = {}
    for d, r in res:
        par_nom.setdefault(r["skill"], []).append((d, r))

    contenus = {nom: textes(lst[0][0], inv) for nom, lst in par_nom.items()}
    noms = sorted(par_nom)
    # Une citation de skill : /nom, `nom`, skills/nom ou « skill nom ». Noms les plus longs d'abord.
    cite_re = re.compile(r"(?:(?<![\w-])/|`|skills/|\bskills?\s+[`«\"]?)("
                         + "|".join(re.escape(n) for n in sorted(noms, key=len, reverse=True)) + r")(?![\w-])")

    skills = []
    for nom in noms:
        lst = par_nom[nom]
        d, r = lst[0]
        copies = [str(x[0]) for x in lst]
        doublon = None
        if len(lst) > 1:
            doublon = "identiques" if len({empreinte(x[0]) for x in lst}) == 1 else "differentes"
        txt = contenus[nom]
        cite = sorted({n for n in cite_re.findall(txt) if n != nom})
        regles = statut_regles(r, doublon)
        for num, j in (jugements.get(nom) or {}).items():
            regles[str(num)] = {"statut": j.get("statut", "na"), "preuves": [j["preuve"]] if j.get("preuve") else [],
                                "correction": j.get("correction", "")}
        info_src = src.get(nom, {})
        cat = r["categorie"]
        if info_src.get("source"):
            origine = "telechargee"
        elif cat == "plugin-ou-synchronisee":
            origine = "synchronisee"
        else:
            origine = "projet" if cat == "projet" else "globale"
        skills.append({
            "nom": nom, "chemin": r["chemin"], "categorie": cat, "origine": origine,
            "source": info_src.get("source"), "mis_a_jour": info_src.get("mis_a_jour"),
            "copies": copies, "doublon": doublon,
            "skill_md_lignes": r["skill_md_lignes"], "corps_lignes": r["corps_lignes"],
            "testee_avec": r["mention_testee_avec"], "liste_a_cocher": r["liste_a_cocher"],
            "fichiers": [f for f in r["fichiers"] if f["lignes"] > inv.SEUIL_SOMMAIRE or f.get("imports_externes")
                         or not f["lie_depuis_skill_md"]],
            "nb_fichiers": len(r["fichiers"]),
            "contenu": (Path(d) / "SKILL.md").read_text(encoding="utf-8", errors="replace")[:CONTENU_MAX],
            "alertes": r["alertes"], "regles": regles,
            "dependances": {
                "skills": cite,
                "bibliotheques": sorted({m for f in r["fichiers"] for m in f.get("imports_externes", [])}),
                "mcp": sorted(set(MCP.findall(txt))),
                "commandes": sorted({c.rstrip(".,;:)") for c in COMMANDE.findall(txt)} - MOTS_VIDES)[:12],
            },
        })
    familles(skills)
    utilisee_par = {s["nom"]: [] for s in skills}
    for s in skills:
        for c in s["dependances"]["skills"]:
            utilisee_par[c].append(s["nom"])
    for s in skills:
        s["dependances"]["utilisee_par"] = sorted(utilisee_par[s["nom"]])

    return {
        "genere_le": datetime.date.today().isoformat(),
        "emplacements": sorted({str(Path(c).expanduser()) for c in cibles}),
        "nb_emplacements_trouves": len(res),
        "skills": skills,
    }


def main():
    if sys.version_info < (3, 10):
        sys.exit("Python 3.10 ou plus récent requis. Essayer : python3.11 rapport_html.py")
    args, sortie, jug = [], "rapport-audit-skills.html", {}
    it = iter(sys.argv[1:])
    for a in it:
        if a == "--sortie":
            sortie = next(it, sortie)
        elif a == "--jugements":
            jug = json.loads(Path(next(it)).read_text(encoding="utf-8"))
        else:
            args.append(a)
    inv = charger_inventaire()
    cibles = [Path(a) for a in args] or inv.EMPLACEMENTS_PAR_DEFAUT
    donnees = construire(cibles, jug)
    brut = json.dumps(donnees, ensure_ascii=False).replace("</", "<\\/")
    html = BALISE.sub(lambda m: m.group(1) + brut + m.group(3), MODELE.read_text(encoding="utf-8"), count=1)
    if sortie == "-":
        sys.stdout.write(html)
        return
    Path(sortie).write_text(html, encoding="utf-8")
    n = len(donnees["skills"])
    k = sum(1 for s in donnees["skills"] if any(v["statut"] == "a_corriger" for v in s["regles"].values()))
    print(f"Rapport écrit : {sortie} — {n} skills, {k} avec au moins un point à corriger.")


if __name__ == "__main__":
    main()
