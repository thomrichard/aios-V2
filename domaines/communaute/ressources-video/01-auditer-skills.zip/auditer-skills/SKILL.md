---
name: auditer-skills
description: "Audite des skills Claude existantes selon le guide officiel d'Anthropic (structure, degrés de liberté, vérifications, dépendances) : inventaire mesuré par script, rapport règle par règle avec preuves, corrections classées, puis application des seules corrections validées. À utiliser quand l'utilisateur veut vérifier, nettoyer, fiabiliser ou partager ses skills, ou demande un audit de skills."
---

# Auditer des skills

Testée avec : Claude Opus 5.5 et Sonnet (octobre 2026), sur trois skills d'exemple aux défauts connus. Avec Haiku, les mesures du script restent justes, mais le jugement des règles 2, 3, 5 et 6 est moins sûr : préférer Sonnet ou Opus pour l'audit.

Règle de conduite : **aucun fichier de skill n'est modifié avant l'accord explicite de l'utilisateur**, correction par correction.

## Fichiers

- [Les règles](references/regles.md) : ce qu'on vérifie, comment le prouver, l'origine de chaque règle.
- [Le modèle de rapport](references/rapport.md) : tableau par skill et liste des priorités.
- Script d'inventaire : `scripts/inventaire.py`. Python 3.10 ou plus récent, bibliothèque standard uniquement, rien à installer. **À exécuter, pas à lire.**
- Rapport visuel : `scripts/rapport_html.py` remplit le modèle `assets/rapport-audit.html` (skills rangées par famille, un statut par skill, panneau de détail avec le contenu de la skill ; fichier autonome, à partager tel quel). Mêmes conditions. **À exécuter, pas à lire.**

## Déroulé

Copier cette liste dans la réponse et la cocher au fil de l'audit :

```
Audit des skills :
- [ ] 1. Inventaire (script)
- [ ] 2. Périmètre confirmé
- [ ] 3. Lecture de chaque skill
- [ ] 4. Vérification des règles
- [ ] 5. Rapport et priorités
- [ ] 6. Arrêt : choix des corrections par l'utilisateur
- [ ] 7. Application et diff
- [ ] 8. Nouvel inventaire et contrôle
```

**1. Inventaire.** Depuis le dossier du projet de l'utilisateur (là où se trouvent ses dossiers `.claude/skills`, s'il en a) :

```bash
python3 <dossier-de-cette-skill>/scripts/inventaire.py
```

Sans argument, le script parcourt `.claude/skills`, `.agents/skills` et `.ai/skills` du dossier courant, puis `~/.claude/skills` et `~/.agents/skills`. Les dossiers passés en argument remplacent cette liste : les utiliser quand l'utilisateur désigne un dossier ou une skill, ou quand ses skills sont ailleurs (par exemple `~/.codex/skills`). Ajouter `--json` pour une sortie exploitable. Le script mesure ; il ne juge pas.

**2. Périmètre.** Montrer le nombre de skills trouvées par emplacement. Si l'utilisateur n'a pas nommé de skill, proposer par défaut les skills personnelles et signaler à part celles d'éditeurs tiers ou de plugins, qui ne seront pas modifiées.

**3. Lecture.** Pour chaque skill du périmètre : lire `SKILL.md`, chaque référence et l'en-tête des scripts.

**4. Vérification.** Appliquer [les règles](references/regles.md). Les mesures viennent du script ; le jugement (degrés de liberté, concision, boucle de vérification) revient à l'audit. Chaque statut « à corriger » cite un fichier et une ligne.

**5. Rapport.** Suivre [le modèle](references/rapport.md). Chaque correction est formulée exactement, prête à appliquer. Produire aussi la page visuelle :

```bash
python3 <dossier-de-cette-skill>/scripts/rapport_html.py [mêmes dossiers qu'à l'étape 1] --sortie rapport-audit-skills.html
```

Les règles 1, 4 et 7 sont mesurées par le script. Les règles 2, 3, 5 et 6 demandent une lecture : écrire leurs statuts dans un fichier JSON au format décrit en tête du script et le passer avec `--jugements`. Si la lecture change le statut d'une règle mesurée, l'y écrire aussi. Ne jamais modifier la page à la main.

**6. Arrêt.** Demander quelles corrections appliquer. Ne rien appliquer sans réponse.

**7. Application.** N'appliquer que les corrections choisies, sans toucher au reste de la skill. Montrer le diff de chaque fichier modifié. Ne jamais modifier une skill de plugin, une copie synchronisée depuis claude.ai ou une skill d'éditeur tiers : proposer la correction à reporter à sa source. Si le projet tient un registre des skills, le mettre à jour.

**8. Contrôle.** Relancer le script sur les skills modifiées et revérifier les règles concernées. Si une règle corrigée échoue encore, ou si un autre élément a changé sans avoir été validé, revenir à l'étape 7.

## Mode rapport seul

Pour une exécution programmée ou sans interlocuteur : faire les étapes 1 à 5 sur le périmètre demandé (à défaut, les emplacements par défaut, sans confirmation), enregistrer le rapport et sa page visuelle dans le dossier indiqué par la demande, et s'arrêter. Aucune correction n'est appliquée dans ce mode.
